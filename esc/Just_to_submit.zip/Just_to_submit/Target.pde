// Kenneth Kaptie
// BUTTON CLASS
// -------------------------------------------
class Target {
  String label, pic;
  float x, y, w, h,xs,ys;
  int boop;
  PImage grug;

  Target(float x, float y, float w, float h) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
boop = int(random(1,3.9));
xs = random(-8,8);
ys = random (-8,8);
  }

  void display() {
    imageMode(CORNER);
switch (boop) {
  case 1:
    grug = loadImage("meattarget.png");
    break;
    
      case 2:
    grug = loadImage("cuptarget.png");
    break;
    
      case 3:
    grug = loadImage("beertarget.png");
    break;
}
    fill(255);
    stroke(0);



 
      grug.resize(int(w), int(h));
      imageMode(CORNER);

    

    image(grug, x, y);
    fill(0);
    //textAlign(LEFT);
    //textSize(20);
    //text(label, x-10, y-15);
//textSize(13);

    //rect(x, y, w, h, 10);
  }

void move() {
x+=xs;
y+=ys;
//if(x>width-(w/2)) xs*=-1;
//if(x<0+(w/2)) xs*=-1;
//if(y<0+(h/2)) ys*=-1;
//if(y>height-(h/2)) ys*=-1;
if(x>width-w) xs*=-1;
if(x<0) xs*=-1;
if(y<0) ys*=-1;
if(y>height-h) ys*=-1;

if (w>8){
w-=.3;
h-=.3;
}
}

  boolean clicked() {

    return (mouseX > x && mouseX < x+w && mouseY > y && mouseY < y+h);
  }
}
