//Maxwell Johnson| March 18 2026| Target game
int score,needed;
char screen;
ArrayList<Target> targets = new ArrayList<Target>();
void setup() {
  background(100, 50, 20);
  score = 0;
  size (800,800);
  screen = 'p';
  frameRate(40);
  needed = 1;
}
void draw() {
  switch(screen) {
    case 'p':
foodGame();
break;
case 'o':
endFoodGame();
break;
  }
}


void foodGame() {
  background(100, 50, 20);
  if (score>=needed*1000) {needed+=1;}
  
  if (targets.size()<needed)targets.add(new Target(int(random(100, width-100)), int(random(100, height-100)), 100, 100));
  for (int i = 0; i<targets.size(); i++) {
    Target target = targets.get(i);
    //if (i>) {
    //  targets.remove(target);
    //}
    target.move();
    target.display();
    if (target.clicked()&&mousePressed) {
      targets.remove(target);
      score+=100;
    }

    if (target.w<10) {
      //  silence.money+=(score/50);
      //score = 0;
      //screen = 'm';
      //endFoodGame();
      screen = 'o';
    }
  }
  scoreboard();
}

void scoreboard () {
rectMode(CENTER);
  fill(127, 127);
  rect(width/2, height-25, width, 50);
  fill (255);
  textSize(20);
  text("Score: "+score, 100, height-20);
}

void endFoodGame() {
  background(255);
  fill(1);
  textSize(50);
  textAlign(CENTER);
  text ("Score:"+score, width/2, height/2);
 // text ("Money earned:"+score/10, 100, 200);
}

void keyPressed() {
if (key == ' '&& screen == 'o'){
screen = 'p';
score=0;
needed=1;

}

}
